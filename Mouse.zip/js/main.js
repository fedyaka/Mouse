$(function(){

	$('.btn_menu').on('click', function(){
    	$('.menu ul').slideToggle();
	});

	$('.slider_inner').slick();



});